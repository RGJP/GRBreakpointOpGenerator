Clear-Host

$Provinces = (Get-ChildItem "$PSScriptRoot" | Where-Object {$_.Name -match '.txt'}) -replace '^...' -replace '.txt' | Out-GridView -Title "Choose one or more province as the AO:" -OutputMode Multiple

"$($Provinces.Count) provinces have been selected:"
$Provinces
""

$Locations = Foreach ($Province in $Provinces) {
    Get-Content -Path "$PSScriptRoot\*$Province*"
}

$NumberDesired = Read-Host "Number of locations desired? ($($Locations.count) total locations available from provinces selected)"
""
"$NumberDesired locations rolled from $($Provinces):"
""
$RandomRollResult = Get-Random -InputObject $Locations -Count $NumberDesired
$RandomRollResult
""

do {
    ""
    $response = Read-Host -Prompt 'Are you satisfied with the roll? (y to continue, n to re-roll)'
    if ($response -eq 'n') {
    clear-host
    "$NumberDesired locations rolled from $($Provinces):"
    ""
    $RandomRollResult = Get-Random -InputObject $Locations -Count $NumberDesired
    $RandomRollResult
    }
} until ($response -eq 'y')

Clear-Host
$Provinces = $Provinces -replace '-',' '

"------------------------------------------------"
""
"OPORD NO.$(Get-Random -Minimum 0 -Maximum 9999)"
""
"AREA OF OPERATIONS:"
$Provinces
""
"OBJECTIVES:"
$RandomRollResult
""
"------------------------------------------------"
""
"If you need help to pinpoint locations on the map, go to:"
"https://swissgameguides.com/maps/ghost_recon_breakpoint/auroa/interactive_map.html"
"and use the Search function to show the exact location on the map."
""
PAUSE
